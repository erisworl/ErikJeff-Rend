﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Inventory : MonoBehaviour
{

    private bool showInventory = false;

    void OnGUI()
    {
        if ((Event.current.Equals(Event.KeyboardEvent("I"))))
        {
            if (!showInventory) showInventory = true;
            else showInventory = false;
        }

        if (showInventory)
        {
            GUI.Box(new Rect(10, 55, 200, 200), "Inventory");
        }
    }

}
